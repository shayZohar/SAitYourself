import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-personal-zone',
  templateUrl: './admin-personal-zone.component.html',
  styleUrls: ['./admin-personal-zone.component.scss']
})
export class AdminPersonalZoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
