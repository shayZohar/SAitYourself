import { BusinessService } from '@/business/services/business.service';
import { IUser, emptyUser } from '../../../user/interfaces/iuser';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { HttpMessagesService } from '@/core/http/http-messages.service';
import { IMessage, emptyMessage } from '@/shared/interfaces/IMessage';
import { AuthenticationService } from '@/core/authentication/authentication.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'business-contact',
  templateUrl: './business-contact.component.html',
  styleUrls: ['./business-contact.component.scss']
})
export class BusinessContactComponent implements OnInit {
   resMessages: Observable<IMessage[]>;
   senMessages: Observable<IMessage[]>;

  constructor(
    private authenticationService: AuthenticationService,
    private bService: BusinessService,
    private messageService: HttpMessagesService
  ) {}

  ////////////////////////////////////////////////////////
  // getting current user from authentication service
  // getting all of user recieved messages
  // emitting the array of messages to messages component
  ////////////////////////////////////////////////////////
  ngOnInit() {
    this.bService.init();
    const currentUser = this.authenticationService.currentUserValue;
    console.log('hello ' + currentUser.fName);
    this.resMessages = this.messageService.getRecievedMessages(currentUser.email);
    this.senMessages = this.messageService.getSentMessages(currentUser.email);
    // for (const item of this.resMessages) {
    //   console.log(item.messContent);
    // }
    // this.bService.updateAsRead(currentUser.email);


  }


}
