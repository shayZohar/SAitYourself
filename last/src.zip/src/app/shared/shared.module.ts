import { HttpClient, HttpClientModule, HttpEventType } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {DataViewModule} from 'primeng/dataview';
import {DialogModule} from 'primeng/dialog';
import {FileUploadModule} from 'primeng/fileupload';
import {MatIconModule} from '@angular/material/icon';

import { NavMainComponent } from './components/nav-main/nav-main.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { MaterialModule } from '@/material/material.module';
import { LoginComponent } from './components/login/login.component';
import { PasswordComponent } from './components/password/password.component';
import { MessagesComponent } from './components/messages/messages.component';
import { PrimeNgModule } from '@/material/primeng.module';
import { FileUpload } from './components/upload/upload.component';
import {CrystalLightboxModule} from '@crystalui/angular-lightbox';
import { MatCheckboxModule } from '@angular/material/checkbox';



@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    PrimeNgModule,
    FormsModule,
    ReactiveFormsModule,
    DataViewModule,
    DialogModule,
    FileUploadModule,
    HttpClientModule,
    MatIconModule,
    RouterModule,
    CrystalLightboxModule,
    MatCheckboxModule,

  ],
  declarations: [
    NavMainComponent,
    SignUpComponent,
    LoginComponent,
    PasswordComponent,
    MessagesComponent,
    FileUpload
  ],
  exports: [
    NavMainComponent,
    SignUpComponent,
    LoginComponent,
    PasswordComponent,
    DataViewModule,
    DialogModule,
    MessagesComponent,
    FileUpload  ]
})
export class SharedModule { }
