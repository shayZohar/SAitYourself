export interface IListDisplay {
  name: string;
  email: string;
}
