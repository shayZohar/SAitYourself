using server.Utilities;
namespace server.Dtos
{
    public class BusinessAboutUpdateDto
    {
        public BAbout BAbout{get;set;}
        public string BMail{get; set;}

    }
}