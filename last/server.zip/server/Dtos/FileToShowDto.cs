namespace server.Dtos
{
    public class FileToShowDto
    {
        public string FileName{ get; set; }
        public string Owner { get; set; }
    }
}