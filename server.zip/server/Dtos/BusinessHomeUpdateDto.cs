using server.Utilities;
namespace server.Dtos
{
    public class BusinessHomeUpdateDto
    {
        public BHome BHome{get;set;}
        public string BMail{get; set;}

    }
}