import { Component, OnInit, Input } from '@angular/core';
import { InavLinks } from '@/shared/interfaces/inav-links';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
             links: InavLinks[] = [ //array for navigation tags
             {
               label: 'home',
               route: ['home'],
             },
             {
               label: 'contact',
               route: ['contact'],
             },
             {
               label: 'putzy',
               route: ['about'],
             },
            ];
  name = 'Amit';
  @Input() name2: string;

  constructor() { }

  ngOnInit() {
  }

}

