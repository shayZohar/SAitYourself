import { Component, OnInit ,Input} from '@angular/core';
import { InavLinks } from '@/shared/interfaces/inav-links';

@Component({
  selector: 'sh-nav-main',
  templateUrl: './nav-main.component.html',
  styleUrls: ['./nav-main.component.scss']
})
export class NavMainComponent implements OnInit {

  @Input() links:InavLinks[];
  constructor() { }

  ngOnInit() {
  }

}
