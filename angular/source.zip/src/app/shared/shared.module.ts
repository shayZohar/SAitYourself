import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavMainComponent } from './components/nav-main/nav-main.component';
import { RouterModule } from '@angular/router';
import { LoginComponent } from '@/user/components/login/login.component';
import { UserModule } from '@/user/user.module';
@NgModule({
  declarations: [NavMainComponent],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    NavMainComponent,
    LoginComponent,
    UserModule
  ]
})
export class SharedModule { }
