export interface InavLinks {
  label: string;
  route: string[];
  icon?: string;
}
